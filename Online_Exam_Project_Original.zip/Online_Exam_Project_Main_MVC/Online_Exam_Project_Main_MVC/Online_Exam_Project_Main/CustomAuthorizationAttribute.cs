﻿
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Online_Exam_Project_Main
{
    using System.Web;
    using System.Web.Mvc;
    using System.Web.Routing;

    public class CustomAuthorizationAttribute : AuthorizeAttribute
    {
        protected override bool AuthorizeCore(HttpContextBase httpContext)
        {
           
            var adminName = httpContext.Session["admin_name"] as string;
            if (!string.IsNullOrEmpty(adminName))
            {
                return true; 
            }

            return false;
        }

        protected override void HandleUnauthorizedRequest(AuthorizationContext filterContext)
        {
          
            filterContext.Result = new RedirectToRouteResult(new RouteValueDictionary(new { controller = "Admin", action = "Login" }));
        }
    }

}